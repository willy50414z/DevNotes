package com.willy.filter;

import java.io.IOException;

import javax.servlet.DispatcherType;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.annotation.WebInitParam;

/**
 * Servlet Filter implementation class MyFilter
 */
@WebFilter(urlPatterns={"/*"}, 
    initParams={
        @WebInitParam(name = "key1", value = "VALUE1"),
        @WebInitParam(name = "key2", value = "VALUE2")
    }, 
    dispatcherTypes={
            DispatcherType.FORWARD, DispatcherType.INCLUDE, 
            DispatcherType.REQUEST, DispatcherType.ERROR, DispatcherType.ASYNC
        })
public class AllFilter implements Filter {

    /**
     * Default constructor. 
     */
    public AllFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
		System.out.println("伺服器關閉");
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here

		// pass the request along the filter chain
		System.out.println("Filter Before Servlet");
		chain.doFilter(request, response);
		System.out.println("Filter After Servlet");
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
		System.out.println("伺服器啟動");
		System.out.println("all filter annotation value1 -- "+fConfig.getInitParameter("key1"));
		System.out.println("all filter annotation value2 -- "+fConfig.getInitParameter("key2"));
	}

}
